"""Unit tests for the simulator"""

import unittest
from src.models.simulator import FreezerAutoloaderSimulator, PattyBelt
from src.models.cartridge import Cartridge


class TestCartridge(unittest.TestCase):
    """Test cartridge functionality"""
    
    def setUp(self):
        self.cartridge = Cartridge(1, "W", 30)
    
    def test_dispense_success(self):
        """Test successful patty dispensing"""
        result = self.cartridge.dispense(5)
        self.assertTrue(result)
        self.assertEqual(self.cartridge.patties_in_stack, 25)
        self.assertEqual(self.cartridge.dispense_queue, 5)
    
    def test_dispense_insufficient_stock(self):
        """Test dispensing with insufficient stock"""
        result = self.cartridge.dispense(35)
        self.assertFalse(result)
        self.assertEqual(self.cartridge.patties_in_stack, 30)
    
    def test_reload(self):
        """Test cartridge reload"""
        self.cartridge.dispense(10)
        self.cartridge.reload()
        self.assertEqual(self.cartridge.patties_in_stack, 30)


class TestSimulator(unittest.TestCase):
    """Test simulator functionality"""
    
    def setUp(self):
        self.simulator = FreezerAutoloaderSimulator()
    
    def test_request_whopper(self):
        """Test requesting Whopper patties"""
        result = self.simulator.request_patties("W", 5)
        self.assertTrue(result)
    
    def test_request_no_stock(self):
        """Test requesting with no stock"""
        # Drain first cartridge
        self.simulator.cartridges[0].dispense(30)
        self.simulator.cartridges[2].dispense(30)
        
        result = self.simulator.request_patties("W", 5)
        self.assertFalse(result)
        self.assertIsNotNone(self.simulator.last_error)


if __name__ == "__main__":
    unittest.main()