"""Main simulator engine for the freezer autoloader"""

import time
from typing import List, Tuple
from src.models.cartridge import Cartridge
from src.utils.constants import (
    CARTRIDGE_CONFIGS, BELT_SPEED_W, BELT_SPEED_WJ
)


class PattyBelt:
    """Represents an animated belt with patties"""
    
    def __init__(self, patty_type: str, belt_speed: float):
        """
        Initialize a patty belt.
        
        Args:
            patty_type: "W" or "WJ"
            belt_speed: Time in seconds for patty to traverse belt
        """
        self.patty_type = patty_type
        self.belt_speed = belt_speed
        self.patties_on_belt: List[Tuple[float, str]] = []  # (start_time, type)
        self.start_time = time.time()
    
    def add_patty(self):
        """Add a patty to the belt"""
        self.patties_on_belt.append((time.time(), self.patty_type))
    
    def update(self) -> Tuple[List[Tuple[float, float]], float]:
        """
        Update belt animation state.
        
        Returns:
            Tuple of (patty_positions, time_remaining)
            patty_positions: List of (position_percent, patty_id)
            time_remaining: Seconds until belt clears
        """
        current_time = time.time()
        positions = []
        remaining_patties = []
        
        for patty_time, patty_type in self.patties_on_belt:
            elapsed = current_time - patty_time
            position = (elapsed / self.belt_speed) * 100
            
            if position <= 100:
                positions.append((position, patty_type))
                remaining_patties.append((patty_time, patty_type))
        
        self.patties_on_belt = remaining_patties
        
        # Calculate time remaining until last patty clears
        if remaining_patties:
            last_patty_time = remaining_patties[-1][0]
            time_remaining = (last_patty_time + self.belt_speed) - current_time
            time_remaining = max(0, time_remaining)
        else:
            time_remaining = 0
        
        return positions, time_remaining
    
    def get_patty_count(self) -> int:
        """Get number of patties currently on belt"""
        return len(self.patties_on_belt)


class FreezerAutoloaderSimulator:
    """Main simulation engine"""
    
    def __init__(self):
        """Initialize the simulator"""
        self.cartridges: List[Cartridge] = []
        self.w_belt = PattyBelt("W", BELT_SPEED_W)
        self.wj_belt = PattyBelt("WJ", BELT_SPEED_WJ)
        self.last_error = None
        
        # Initialize cartridges
        for cart_id, config in CARTRIDGE_CONFIGS.items():
            cartridge = Cartridge(
                cart_id,
                config["type"],
                config["initial_stack"]
            )
            self.cartridges.append(cartridge)
    
    def request_patties(self, patty_type: str, count: int = 1) -> bool:
        """
        Request patties to be dispensed.
        
        Args:
            patty_type: "W" or "WJ"
            count: Number of patties to dispense
            
        Returns:
            True if successful, False otherwise
        """
        # Find cartridges for this type
        matching_cartridges = [c for c in self.cartridges if c.patty_type == patty_type]
        
        if not matching_cartridges:
            self.last_error = f"No cartridges found for type {patty_type}"
            return False
        
        # Try to dispense from first available cartridge
        for cartridge in matching_cartridges:
            if cartridge.dispense(count):
                # Add patties to belt
                belt = self.w_belt if patty_type == "W" else self.wj_belt
                for _ in range(count):
                    belt.add_patty()
                self.last_error = None
                return True
        
        # If we get here, no cartridge had enough patties
        self.last_error = f"{patty_type}hoppers request - no {patty_type} patties current loaded"
        return False
    
    def reload_cartridge(self, cartridge_id: int) -> bool:
        """
        Reload a specific cartridge.
        
        Args:
            cartridge_id: ID of cartridge to reload (1-4)
            
        Returns:
            True if successful
        """
        for cartridge in self.cartridges:
            if cartridge.id == cartridge_id:
                cartridge.reload()
                return True
        return False
    
    def reset_stack_counter(self, cartridge_id: int) -> bool:
        """
        Reset the stack counter for a cartridge.
        
        Args:
            cartridge_id: ID of cartridge (1-4)
            
        Returns:
            True if successful
        """
        for cartridge in self.cartridges:
            if cartridge.id == cartridge_id:
                cartridge.reset_stack_counter()
                return True
        return False
    
    def get_cartridge_info(self, cartridge_id: int) -> dict:
        """Get information about a specific cartridge"""
        for cartridge in self.cartridges:
            if cartridge.id == cartridge_id:
                return cartridge.get_info()
        return {}
    
    def get_all_cartridges_info(self) -> List[dict]:
        """Get information about all cartridges"""
        return [c.get_info() for c in self.cartridges]
    
    def update(self) -> dict:
        """
        Update simulation state.
        
        Returns:
            Dictionary with current state
        """
        w_positions, w_time_remaining = self.w_belt.update()
        wj_positions, wj_time_remaining = self.wj_belt.update()
        
        return {
            "w_belt": {
                "positions": w_positions,
                "time_remaining": w_time_remaining,
                "patty_count": self.w_belt.get_patty_count(),
            },
            "wj_belt": {
                "positions": wj_positions,
                "time_remaining": wj_time_remaining,
                "patty_count": self.wj_belt.get_patty_count(),
            },
            "cartridges": self.get_all_cartridges_info(),
            "last_error": self.last_error,
        }
    
    def get_dispense_queues(self) -> dict:
        """Get current dispense queues"""
        w_queue = sum(c.dispense_queue for c in self.cartridges if c.patty_type == "W")
        wj_queue = sum(c.dispense_queue for c in self.cartridges if c.patty_type == "WJ")
        
        return {"W": w_queue, "WJ": wj_queue}